package juego.modelo;
import juego.util.*;
/**
 * Tablero de juego.
 * @author Alejandro Ortega Martínez.
 * @version 1.0
 * @see Celda
 * @see Tipo
 *
 */
public class Tablero {

	/**
	 * Numero de filas del tablero. No cambia en ningún momento.
	 */
	private static int NUMERO_FILAS = 8;
	
	/**
	 * Numero de columnas del tablero. No cambia en ningún momento.
	 */
	private static int NUMERO_COLUMNAS = 8;
	
	/**
	 * Array de dos dimensiones que contiene las celdas.
	 */
	private Celda celdas[][];
	
	/**
	 * Las coordenadas de las esquinas del tablero son las siguientes:
	 * 
	 * 	(0,0)		(0,7)
	 * 
	 * 
	 * 	(7,0)		(7,7)
	 */
	
	/**
	 * Constructor del tablero.
	 * @see Celda
	 */
	public Tablero() {
		/**
		 * Inicializamos el array de celdas de dos dimensiones.
		 */
		celdas = new Celda[NUMERO_FILAS][NUMERO_COLUMNAS];
		
		/**
		 * Creamos nuevos objetos de tipo celda y los guardamos en el array.
		 * Se crean 8x8=64 celdas.
		 */
		for (int i=0;i<8;i++) {
			for (int j=0;j<8;j++) {
				celdas[i][j] = new Celda(i,j);
			}
		}
	}
	
	


	/**
	 * Metodo que coloca una determinada pieza en una determinada celda.
	 * @param pieza pieza que se desea colocar.
	 * @see Pieza
	 * @param celda celda donde se desea colocar la pieza.
	 * @see Celda
	 * <p>
	 * @see Pieza#establecerCelda(Celda)
	 * @see Celda#establecerPieza(Pieza)
	 */
	public void colocar(Pieza pieza, Celda celda) {
		if(pieza!=null) {	//Comprobamos si le hemos pasado una pieza
		pieza.establecerCelda(celda);	
		}
		celda.establecerPieza(pieza);
		
		
	}
	
	/**
	 * Coloca una determinada pieza en una celda referenciada por su fila y columna.
	 * @param pieza pieza que se desea colocar.
	 * @see Pieza
	 * @param fila Fila de la celda en la que se quiere colocar la pieza.
	 * @see Celda
	 * @param columna Columna de la celda en la que se desea colocar la pieza.
	 * <p>
	 * @see Pieza#establecerCelda(Celda)
	 * @see Celda#establecerPieza(Pieza)
	 */
	public void colocar(Pieza pieza, int fila, int columna) {
		celdas[fila][columna].establecerPieza(pieza);
		pieza.establecerCelda(this.celdas[fila][columna]);
		
	}
	
	
	/**
	 * Comprueba si una celda está en el tablero.
	 * @param fila fila de la celda a comprobar.
	 * @param columna Columna de la celda a comprobar.
	 * @return True si la celda está en el tablero, False si no lo está.
	 * @see celdas
	 */
	private boolean estaEnTablero(int fila, int columna) {
		boolean esta = false;
		if (fila < this.celdas.length && fila >= 0) {
			if (columna < this.celdas[0].length && columna >= 0) {
				esta = true;
			}
		}
		return esta;
	}

	
	/**
	 * 
	 * Dada una fila y una columna, devuelve la celda correspondiente.
	 * @param fila Fila de la celda.
	 * @param columna Columna de la Celda.
	 * @return Celda correspondiente a la fila y la columna pasadas.
	 * @see Celda
	 * 
	 */
	public Celda obtenerCelda(int fila, int columna) {
		if(this.estaEnTablero(fila, columna)==true) {
		
		return this.celdas[fila][columna];
	}
		else {
		return null;
		}
	}
	
	/**
	 * 
	 * Dada una celda con el formato de letras para las columnas y números para las filas,
	 * devuelve la celda en cuestión.
	 * @param texto Testo en el formato (a1).
	 * @return celda referente a las coordenadas pasadas.
	 * @see Celda
	 */
	public Celda obtenerCeldaParaNotacionAlgebraica(String texto) {

		/**
		 * Se inicializan la fila y la columna a un valor irreal, para que no haya conflico
		 */
		int fila = -1;
		int columna = -1;
		
		/**
		 * Se comprueba con que columna corresponde el primer caracter.
		 */
		switch (texto.charAt(0)) {
		case 'a':
			columna = 0;
			break;
		case 'b':
			columna = 1;
			break;
		case 'c':
			columna = 2;
			break;
		case 'd':
			columna = 3;
			break;
		case 'e':
			columna = 4;
			break;
		case 'f':
			columna = 5;
			break;
		case 'g':
			columna = 6;
			break;
		case 'h':
			columna = 7;
			break;
		default:
			columna= -1;
		}
		
		/**
		 * Se comprueba con que fila corresponde el segundo caracter.
		 */
		switch (texto.charAt(1)) {
		case '1':
			fila = 7;
			break;
		case '2':
			fila = 6;
			break;
		case '3':
			fila = 5;
			break;
		case '4':
			fila = 4;
			break;
		case '5':
			fila = 3;
			break;
		case '6':
			fila = 2;
			break;
		case '7':
			fila = 1;
			break;
		case '8':
			fila = 0;
			break;
		default:
			fila=-1;
		}

		/**
		 * Si los valores de pieza y columna han quedado en el valor irreal,
		 * se devuelve null, ya que esa celda no existe.
		 */
		if ((fila == -1) || (columna == -1)) {
			return null;
		} else {
			return this.celdas[fila][columna];
		}
	}
	
	

	/**
	 * Devuelve un array de una dimensión con todas las celdas del tablero.
	 * @return Array de una dimensión con todas las celdas.
	 */
	public Celda[] obtenerCeldas() {
		Celda[] celdas = new Celda[64];
		for (int i=0;i<8;i++) {
			for (int j=0;j<8;j++) {
				celdas[i*8+j]= this.celdas[i][j];	

		}
	}
		return celdas;
	}
	
	/**
	 * Dada una celda, nos devuelve sus coordenadas en notación algebraica.
	 * @param celda Celda de la que queremos saber sus coordenadas.
	 * @return String con las coordenadas en notación algebraica (a1).
	 */
	public String obtenerCoordenadaEnNotacionAlgebraica(Celda celda) {
		char columna=0;
		char fila=0;
		boolean flag=true;
		StringBuilder algebraica = new StringBuilder();
		
		/**
		 * Según la columna de la celda, se guarda el caracter correspondiente
		 * en la variable columna.
		 */
		switch (celda.obtenerColumna()){
		case 0: columna='a'; break;
		case 1: columna='b'; break;
		case 2: columna='c'; break;
		case 3: columna='d'; break;
		case 4: columna='e'; break;
		case 5: columna='f'; break;
		case 6: columna='g'; break;
		case 7: columna='h'; break;
		default: flag=false;
		}
		
		/**
		 * Según la fila de la celda, se guarda el número correspondiente.
		 * en la variable fila.
		 */
		switch (celda.obtenerFila()){
		case 0: fila='8'; break;
		case 1: fila='7'; break;
		case 2: fila='6'; break;
		case 3: fila='5'; break;
		case 4: fila='4'; break;
		case 5: fila='3'; break;
		case 6: fila='2'; break;
		case 7: fila='1'; break;
		default: flag=false;
		}
		/**
		 * Construimos un String con las variables pieza y columna.
		 */
		algebraica.append(columna);
		algebraica.append(fila);
		
		String algebraica2 = algebraica.toString();
		/**
		 * Si se ha pasado una pieza que no pertenece al tablero, se devuelve null.
		 */
		if (flag==true) {
		return algebraica2;
		}
		else {
			return null;
		}
		}
	
	/**
	 * Devuelve cuantas columnas tiene el tablero.
	 * @return Numero de columnas del tablero.
	 */
	public int obtenerNumeroColumnas() {
		return NUMERO_COLUMNAS;
	}
	
	/**
	 * Devuelve cuantas filas tiene el tablero.
	 * @return Numero de filas del tablero.
	 */
	public int obtenerNumeroFilas() {
		return NUMERO_FILAS;
	}
	
	/**
	 * Devuelve el número de piezas de un determinado color que hay en el tablero.
	 * @param color Color de las piezas que se quieren contar.
	 * @return Numero de piezas del color que se pasa como argumento.
	 * @see Celda#estaVacia()
	 * @see Celda#obtenerPieza()
	 * @see Pieza#obtenerColor()
	 */
	public int obtenerNumeroPiezas(Color color){
		int total=0;
		Celda[] celdas = obtenerCeldas();
		Pieza pieza;
		
		for(int i=0; i<64; i++) {
			if(celdas[i].estaVacia()==false) {
				pieza = celdas[i].obtenerPieza();
				if(pieza.obtenerColor()==color) {
					total++;
				}
			}
		}
		
		return total;
	}
	
	/**
	 * Devuleve el sentido de movimiento desde una celda origen a una celda destino.
	 * @param origen Celda origen del movimiento
	 * @param destino Celda destino del movimiento
	 * @return Sentido del movimiento
	 * @see juego.util.Sentido
	 * @see Celda#obtenerColumna()
	 * @see Celda#obtenerFila()
	 */
	public Sentido obtenerSentido(Celda origen, Celda destino) {
		
		Sentido sentido = null;
		
		if (origen.obtenerColumna()==destino.obtenerColumna()) {
			if(origen.obtenerFila()>destino.obtenerFila()) {
				sentido = Sentido.VERTICAL_N;
			}
			else {
				sentido = Sentido.VERTICAL_S;
			}
		}
		
		if (origen.obtenerFila()==destino.obtenerFila()) {
			if (origen.obtenerColumna()>destino.obtenerColumna()) {
				sentido = Sentido.HORIZONTAL_O;
				}
			else {
				sentido = Sentido.HORIZONTAL_E;
			}
		}
		
		
		if(Math.abs(origen.obtenerColumna()-destino.obtenerColumna())==Math.abs(origen.obtenerFila()-destino.obtenerFila())) {
			if ((origen.obtenerColumna()<destino.obtenerColumna())){
				if ((origen.obtenerFila()>destino.obtenerFila())) {
					sentido = Sentido.DIAGONAL_NE;
				}
				else {
					sentido = Sentido.DIAGONAL_SE;
				}
			}
			else {
				if ((origen.obtenerFila()>destino.obtenerFila())) {
					return Sentido.DIAGONAL_NO;
				}
				else {
					return Sentido.DIAGONAL_SO;
				}
			}
		}
		return sentido;
	}
	
	/**
	 * Metodo privado que devuelve un String de la fila que queremos imprimir.
	 * @param fila Fila de la que queremos obtener el String
	 * @return String con la fila a imprimir
	 */
	private String obtenerFilaToString( int fila) {
		String string="";
		Pieza pieza;
		Color color;
		Tipo tipo;
		char tipoCaracter;
		for(int i=0;i<8;i++) {
			if (this.celdas[fila][i].estaVacia()==false) {
				pieza = this.celdas[fila][i].obtenerPieza();
				color = pieza.obtenerColor();
				tipo = pieza.obtenerTipo();
				tipoCaracter = tipo.toChar();
				
				string += "" + tipoCaracter + color.toChar() + " ";
			}
			else {
				string+= "-- ";
			}
		}
		return string;
	}
	
	/**
	 * Metodo toString para imprimir el estado del tablero.
	 */
	public String toString() {
	String string="";
	String string1="";
	String string2="";
	String string3="";
	String string4="";
	String string5="";
	String string6="";
	String string7="";
	String string8="";
	
	
	string8=obtenerFilaToString(0);
	string7=obtenerFilaToString(1);
	string6=this.obtenerFilaToString(2);
	string5=this.obtenerFilaToString(3);
	string4=this.obtenerFilaToString(4);
	string3=this.obtenerFilaToString(5);
	string2=this.obtenerFilaToString(6);
	string1=this.obtenerFilaToString(7);
	
	string= "8\t" + string8 + "\n" + "7\t" + string7 + "\n" + "6\t" + string6 + "\n" + "5\t" + string5 + "\n" +
			"4\t" + string4 + "\n" + "3\t" + string3 + "\n" + "2\t" + string2 + "\n" + "1\t" + string1 + "\n" + 
			"\ta  b  c  d  e  f  g  h";
	
	return string;

	}
	
	
	}

