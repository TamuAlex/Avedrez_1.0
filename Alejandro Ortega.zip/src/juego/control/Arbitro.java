package juego.control;

import juego.modelo.*;
import juego.util.*;

/**
 * Comprueba las reglas del juego y efectua los cambios en el tablero.
 * @author Alejandro Ortega Martinez
 * @version 1.3
 * @see juego.control#Tablero
 * 
 */
public class Arbitro {
	
	/**
	 * Yablero del juego.
	 */
	private Tablero tablero;
	
	/**
	 * Jugador Blanco.
	 */
	private Color jugadorB = Color.BLANCO;
	
	/**
	 * Jugador Negro.
	 */
	private Color jugadorN = Color.NEGRO;
	
	/**
	 * Color del turno actual.
	 */
	private Color turno = null;
	
	/**
	 * Numero de jugadas.
	 */
	private int numeroJugada = 0;
	
	/**
	 * Constructor del Arbitro.
	 * @param tablero Tablero de la partida
	 */
	public Arbitro(Tablero tablero) {

		this.tablero = tablero;

	}
	
	/**
	 * Cambia el turno actual por el del jugador del otro color. 
	 */
	public void cambiarTurno() {
		if (this.turno == this.jugadorB) {
			this.turno = this.jugadorN;
		} else {
			this.turno = this.jugadorB;
		}
	}
	
	/**
	 * Coloca las piezas en la disposición normal al comienzo de la partida.
	 */
	public void colocarPiezas() {
		
		/**
		 * Se colocan los Peones.
		 */
		for (int i = 0; i < this.tablero.obtenerNumeroColumnas(); i++) {
			tablero.colocar(new Pieza((Tipo.PEON), Color.BLANCO), 6, i);
			tablero.colocar(new Pieza((Tipo.PEON), Color.NEGRO), 1, i);
		}
		/**
		 * Se colocan las Torres.
		 */
		tablero.colocar(new Pieza((Tipo.TORRE), Color.NEGRO), 0, 0);
		tablero.colocar(new Pieza((Tipo.TORRE), Color.NEGRO), 0, 7);
		tablero.colocar(new Pieza((Tipo.TORRE), Color.BLANCO), 7, 0);
		tablero.colocar(new Pieza((Tipo.TORRE), Color.BLANCO), 7, 7);
		
		/**
		 * Se colocan los caballos.
		 */
		tablero.colocar(new Pieza((Tipo.CABALLO), Color.NEGRO), 0, 1);
		tablero.colocar(new Pieza((Tipo.CABALLO), Color.NEGRO), 0, 6);
		tablero.colocar(new Pieza((Tipo.CABALLO), Color.BLANCO), 7, 1);
		tablero.colocar(new Pieza((Tipo.CABALLO), Color.BLANCO), 7, 6);
		
		/**
		 * Se colocan los afiles.
		 */
		tablero.colocar(new Pieza((Tipo.ALFIL), Color.NEGRO), 0, 2);
		tablero.colocar(new Pieza((Tipo.ALFIL), Color.NEGRO), 0, 5);
		tablero.colocar(new Pieza((Tipo.ALFIL), Color.BLANCO), 7, 2);
		tablero.colocar(new Pieza((Tipo.ALFIL), Color.BLANCO), 7, 5);
		
		/**
		 * Se colocan las Damas
		 */
		tablero.colocar(new Pieza((Tipo.DAMA), Color.NEGRO), 0, 3);
		tablero.colocar(new Pieza((Tipo.DAMA), Color.BLANCO), 7, 3);
		
		/**
		 * Se colocan los Reyes.
		 */
		tablero.colocar(new Pieza((Tipo.REY), Color.NEGRO), 0, 4);
		tablero.colocar(new Pieza((Tipo.REY), Color.BLANCO), 7, 4);
		
		/**
		 * El turno comienza en el jugador blanco.
		 */
		this.turno = this.jugadorB;
	}
	
	/**
	 * Se coloca una pieza especifica en una celda especifica.
	 * @param tipo Array de tipos de las piezas que queremos colocar.
	 * @param color Array de colores de las piezas que queremos colocar.
	 * @param coordenadas Array de dos dimensiones con las coordenadas donde queremos colocar las piezas.
	 */
	public void colocarPiezas(Tipo[] tipo, Color[] color, int[][] coordenadas) {
		for (int i = 0; i < tipo.length; i++) {
			tablero.colocar(new Pieza((tipo[i]), color[i]), coordenadas[i][0], coordenadas[i][1]);
		}
	}
	
	/**
	 * Comprueba si , dada una celda origen y una destino, la pieza en la celda origen se puede mover a la celda destino.
	 * @param origen Celda origen donde esta la pieza que queremos mover.
	 * @param destino Celda destino a la que queremos llegar.
	 * @return true si el movimiento es legal o false si no lo es.
	 */
	public boolean esMovimientoLegal(Celda origen, Celda destino) {
		Sentido sentido = tablero.obtenerSentido(origen, destino);
		boolean legalidad = false;

		if (!origen.estaVacia()) {
			Pieza pieza = origen.obtenerPieza();
			Tipo tipo = pieza.obtenerTipo();
			Color color = pieza.obtenerColor();
			
			/**
			 * Comprobamos la legalidad si la pieza es una Torre.
			 */
			if (tipo == Tipo.TORRE) { 
				if (sentido == Sentido.VERTICAL_S || sentido == Sentido.VERTICAL_N || sentido == Sentido.HORIZONTAL_E
						|| sentido == Sentido.HORIZONTAL_O) {
					if (comprobacionCaminoVacio(origen, destino, sentido) && sePuedeColocar(destino, color)) {
						legalidad = true;
					}
				}
			}
			
			/**
			 * Comprobamos la legalidad si la pieza es un Alfil.
			 */
			else if (tipo == Tipo.ALFIL) {
				if (sentido == Sentido.DIAGONAL_NE || sentido == Sentido.DIAGONAL_NO || sentido == Sentido.DIAGONAL_SE
						|| sentido == Sentido.DIAGONAL_SO) {
					if (comprobacionCaminoVacio(origen, destino, sentido) && sePuedeColocar(destino, color)) {
						legalidad = true;
					}
				}
				
			/**
			* Comprobamos la legalidad si la pieza es una Dama.
			*/	
			} else if (tipo == Tipo.DAMA) { 
				if (sentido != null) {
					if (comprobacionCaminoVacio(origen, destino, sentido) && sePuedeColocar(destino, color)) {
						legalidad = true;
					}
				}
			
			/**
			* Comprobamos la legalidad si la pieza es un rey.
			*/
			} else if (tipo == Tipo.REY) { 
				int desplazamientoColumnas = Math.abs(origen.obtenerColumna() - destino.obtenerColumna()); // 0
				int desplazamientoFilas = Math.abs(origen.obtenerFila() - destino.obtenerFila()); // 7

				if ((desplazamientoFilas == 1 && desplazamientoColumnas == 0)
						|| (desplazamientoFilas == 0 && desplazamientoColumnas == 1)
						|| (desplazamientoFilas == 1 && desplazamientoColumnas == 1)) {

					legalidad = sePuedeColocar(destino, color);
				} else {
					legalidad = false;
				}
			/**
			* Comprobamos la legalidad si la pieza es un Peon.
			*/
			} else if (tipo == Tipo.PEON) { 
				legalidad = comprobacionPeonLegal(origen, destino, sentido, color);
		
			/**
			* Comprobamos la legalidad si la pieza es un Caballo.
			*/
			} else if (tipo == Tipo.CABALLO) {
				legalidad = comprobacionCaballoLegal(origen, destino, color);
		}
		}
		
		return legalidad;
	}
	
	
	/**
	 * Comprueba la legalidad del movimiento del caballo.
	 * @param origen Celda origen donde esta el caballo.
	 * @param destino Celda destino donde se quiere mover el caballo.
	 * @param color color del caballo.
	 * @return true si se puede mover y false si no.
	 */
	private boolean comprobacionCaballoLegal(Celda origen, Celda destino, Color color) {
		int desplazamientoColumnas = Math.abs(origen.obtenerColumna() - destino.obtenerColumna());
		int desplazamientoFilas = Math.abs(origen.obtenerFila() - destino.obtenerFila());
		boolean legalidad = false;
		if (desplazamientoFilas == 2 && desplazamientoColumnas == 1) {
			legalidad = sePuedeColocar(destino, color);
		} else if (desplazamientoFilas == 1 && desplazamientoColumnas == 2) {
			legalidad = sePuedeColocar(destino, color);
		} else {
			legalidad = false;
		}
		return legalidad;
	}

	
	
	
	/**
	 * Comprueba la legalidad del movimiento del Peón.
	 * @param origen Celda origen donde esta el peón.
	 * @param destino Celda destino donde se quiere mover el peón.
	 * @param direccion Dirección en la que se quiere mover el peón.
	 * @param color Color del peón.
	 * @return True si el peón se puede mover y false si no.
	 */
	private boolean comprobacionPeonLegal(Celda origen, Celda destino, Sentido direccion, Color color) {
		int desplazamientoColumnas = Math.abs(origen.obtenerColumna() - destino.obtenerColumna());
		int desplazamientoFilas = Math.abs(origen.obtenerFila() - destino.obtenerFila()); // Peon Negro
		boolean legalidad = false;
		Pieza pieza = origen.obtenerPieza();
		
		/**
		 * Comprobamos los peones negros.
		 */
		if (color == Color.NEGRO) {
			
			/**
			 * Comprobamos si se quiere mover verticalmente.
			 */
			if (direccion == Sentido.VERTICAL_S) {
				if (pieza.esPrimerMovimiento() == true) {
					if (desplazamientoFilas <= 2 && desplazamientoFilas > 0) {
						if (this.comprobacionCaminoVacio(origen, destino, direccion) == true) {
							 legalidad = sePuedeColocar(destino, color);
						}
					}
				} else {
					if (desplazamientoFilas <= 1 && desplazamientoFilas >= 0) {
						legalidad = sePuedeColocar(destino, color);
					}
				}
				
				/**
				 * Comprobamos si quiere moverse diagonalmente para comer otra pieza.
				 */
			} else if (direccion == Sentido.DIAGONAL_SE || direccion == Sentido.DIAGONAL_SO) {
				if (desplazamientoColumnas == 1 && desplazamientoFilas == 1) {
					if (destino.estaVacia() == false) {
						if (destino.obtenerPieza().obtenerColor() == Color.BLANCO) {
							legalidad = true;
						}
					}
				}
			} else {
				legalidad = false;
			}
		}
		
		/**
		 * Comprobamos los peones blancos.
		 */
		if (color == Color.BLANCO) {
			
			/**
			 * Comprobamos si se quiere mover verticalmente.
			 */
			if (direccion == Sentido.VERTICAL_N) {
				if (pieza.esPrimerMovimiento() == true) {
					if (desplazamientoFilas <= 2 && desplazamientoFilas > 0) {
						if (this.comprobacionCaminoVacio(origen, destino, direccion) == true) {
							legalidad = sePuedeColocar(destino, color);
						}
					}
				} else if (desplazamientoFilas <= 1 && desplazamientoFilas > 0) {
					legalidad = sePuedeColocar(destino, color);
				}
				
				/**
				 * Comprobamos si quiere moverse diagonalmente para comer otra pieza.
				 */
			} else if (direccion == Sentido.DIAGONAL_NE || direccion == Sentido.DIAGONAL_NO) {
				if (desplazamientoColumnas == 1 && desplazamientoFilas == 1) {
					if (destino.estaVacia() == false) {
						if (destino.obtenerPieza().obtenerColor() == Color.NEGRO) {
							legalidad = true;
						}
					}
				}
			} else {
				legalidad = false;
			}
	}
		return legalidad;
	}
	
	/**
	 * Comprueba si el camino entre la celda origen y la celda destino está vacio.
	 * @param origen Celda origen.
	 * @param destino Celda destino.
	 * @param direccion dirección del movimiento.
	 * @return true si el camino está vacio y false si no.
	 */
	private boolean comprobacionCaminoVacio(Celda origen, Celda destino, Sentido direccion) {
		boolean estaVacia = true;
		int columnaOrigen = origen.obtenerColumna();
		int columnaDestino = destino.obtenerColumna();
		int filaOrigen = origen.obtenerFila();
		int filaDestino = destino.obtenerFila();

		int desplazamientoFila = direccion.obtenerDesplazamientoEnFilas();
		int desplazamientoColumna = direccion.obtenerDesplazamientoEnColumnas();
		boolean seguir = true;

		while (seguir) {
			columnaOrigen = columnaOrigen + desplazamientoColumna;
			filaOrigen = filaOrigen + desplazamientoFila;

			if (filaOrigen != filaDestino
					|| columnaOrigen != columnaDestino && (filaOrigen != origen.obtenerFila() || columnaOrigen != origen.obtenerColumna())) {
				if (tablero.obtenerCelda(filaOrigen, columnaOrigen) != null) { // si la celda existe


					if (tablero.obtenerCelda(filaOrigen, columnaOrigen).estaVacia() == false) {

						seguir = false;
						estaVacia = false;
					}
				} else {
					seguir = false; // si no existe forzamos la salida
				}

			} else {
				seguir = false;
			}
		}
		return estaVacia;
	}

	/**
	 * Comprobamos si una pieza de un color determinado se puede colocar en una celda.
	 * @param destino Celda donde queremos colocar una pieza.
	 * @param color Color de la pieza que queremos colocar.
	 * @return true si se puede colocar, false si no.
	 */
	private boolean sePuedeColocar(Celda destino, Color color) {
		boolean sePuede = false;

		if (destino.estaVacia() == true) {
			sePuede = true; /** Si esta vacia se puede colocar*/
		} else {
			if (destino.obtenerPieza().obtenerColor() != color) {
				sePuede = true; /** Si se puede comer a la pieza que esta ahi se puede colocar */
			}

		}
		return sePuede;
	}

	/**
	 * Comprueba si el rey de un color dado está en jaque.
	 * @param color Color del rey a comprobar.
	 * @return True si esta e jaque, false si no.
	 */
	public boolean estaEnJaque(Color color) {
		Celda celdasTotales[] = new Celda[64];
		Pieza piezasContrarias[] = new Pieza[16];
		int contador = 0;
		celdasTotales = tablero.obtenerCeldas();
		Celda celdaRey = null;
		boolean estaEnJaque = false;
		boolean intermedio;

		for (int i = 0; i < celdasTotales.length; i++) {
			/** Obtenemos todas las piezas contrarias */
			if (!celdasTotales[i].estaVacia()) {
				if (celdasTotales[i].obtenerColorDePieza() != color) {
					piezasContrarias[contador] = celdasTotales[i].obtenerPieza();
					contador++;
				}
			}
			/** Obtenemos la celda del rey a comprobar */
			if (celdasTotales[i].obtenerColorDePieza() == color) {
				if (celdasTotales[i].obtenerPieza().obtenerTipo() == Tipo.REY) {
					celdaRey = celdasTotales[i];
				}
			}
		}
		/**
		 * Comprobamos si alguna de las piezas contarias se pueden mover a la celda del rey
		 */
		for (int i = 0; i < contador && estaEnJaque == false; i++) {
			intermedio = this.esMovimientoLegal(piezasContrarias[i].obtenerCelda(), celdaRey);

			if (intermedio) {
				estaEnJaque = true;
			}
		}
		return estaEnJaque;
	}
 
	/**
	 * Comprobamos si, tras simular el movimiento, el rey quedaría en jaque.
	 * @param origen Celda origen de la pieza que vamos a mover.
	 * @param destino Celda destino donde la queremos mover.
	 * @return true si va a estar en jaque, false si no.
	 */
	public boolean estaEnJaqueTrasSimularMovimientoConTurnoActual(Celda origen, Celda destino) {
		Pieza piezaRey = origen.obtenerPieza();
		Pieza piezaDestino = destino.obtenerPieza();
		boolean estaEnJaque = false;
		
		/** movemos la pieza y comprobamos si el rey se queda en jaque */
		if (this.esMovimientoLegal(origen, destino)) {
			this.tablero.colocar(null, origen);
			this.tablero.colocar(piezaRey, destino);
			estaEnJaque = this.estaEnJaque(piezaRey.obtenerColor());

			/** Retornamos el tablero al estado inicial */
			this.tablero.colocar(piezaRey, origen);
			if (piezaDestino != null) {
				this.tablero.colocar(piezaDestino, destino);
			}

		}
		return estaEnJaque;
	}

	/**
	 * Mueve una pieza de una celda a otra.
	 * @param origen Celda origen donde está la pieza.
	 * @param destino Celda destino donde la queremos mover.
	 */
	public void mover(Celda origen, Celda destino) {
		Pieza pieza = origen.obtenerPieza();
		destino.establecerPieza(pieza);
		pieza.establecerCelda(destino);
		origen.eliminarPieza();
		pieza.marcarPrimerMovimiento();

		this.numeroJugada++;
	}

	/**
	 * Devuelve la casilla origen y la casilla destino en notación algebraica.
	 * @param origen Celda origen del movimiento
	 * @param destino Celda destino del movimiento
	 * @return String con la jugada en el formato (a1a3).
	 */
	public String obtenerJugadaEnNotacionAlgebraica(Celda origen, Celda destino) {

		String celda1 = tablero.obtenerCoordenadaEnNotacionAlgebraica(origen);
		String celda2 = tablero.obtenerCoordenadaEnNotacionAlgebraica(destino);

		return celda1 + celda2;

	}

	/**
	 * Devuelve el numero de jugadas totales que se han hecho.
	 * @return Numero de jugadas totales.
	 */
	public int obtenerNumeroJugada() {
		return this.numeroJugada;
	}
	
	/**
	 * Devuelve el color del jugador con el turno actual.
	 * @return Color del jugador actual
	 */
	public Color obtenerTurno() {
		return this.turno;
	}
}
