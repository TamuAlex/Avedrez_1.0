package juego.modelo;

/**
 * Enumeración de los posibles tipos de piezas.
 * @author Alejandro Ortega Martínez
 * @version 1.0
 * @see Pieza
 */
public enum Tipo {
	/**
	 * Tipo Rey.
	 */
	REY('R'),
	
	/**
	 * Tipo Dama.
	 */
	DAMA('D'),
	
	/**
	 * Tipo Torre.
	 */
	TORRE('T'),
	
	/**
	 * Tipo Alfil.
	 */
	ALFIL('A'),
	
	/**
	 * Tipo caballo.
	 */
	CABALLO('C'),
	
	/**
	 * Tipo Peón.
	 */
	PEON('P');
	
	/**
	 * Letra que identifica cada tipo.
	 */
	private char letra;
	
	/**
	 * Constructor privado de la enumeración.
	 * @param car caracter identificativo del tipo.
	 */
	private Tipo (char car) {
		this.letra=car;
	}
	
	/**
	 * Método toChar de la enumeración.
	 * @return Devuelve el caracter identificativo del tipo.
	 */
	public char toChar() {
		return letra;
	}

}
