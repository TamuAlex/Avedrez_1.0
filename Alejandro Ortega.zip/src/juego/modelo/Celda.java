package juego.modelo;

/**
 * Celdas del tablero de ajedrez. 
 * @author Alejandro Ortega Martinez
 * @version 1.0
 *
 */
public class Celda {

	/**
	 * Columna de la Celda.
	 */
	private int columna;
	
	/**
	 * Fila de la Celda.
	 */
	private int fila;
	
	/**
	 * Pieza que hay en la celda.
	 * @see Pieza
	 */
	private Pieza pieza;
	
	/**
	 *  Constructor de la celda.
	 * @param fila Fila de la celda que vamos a crear
	 * @param columna Columna de la fila que vamos a crear
	 */
	public Celda(int fila, int columna) {
		this.columna=columna;
		this.fila=fila;
	}
	
	/**
	 * Elimina de la Celda la pieza que haya en ella.
	 */
	public void eliminarPieza() {
		this.pieza=null;
	}
	
	/**
	 * Coloca en la celda la pieza pasada por parametro.
	 * @param pieza Pieza a colocar en la celda
	 * @see Pieza
	 */
	public void establecerPieza(Pieza pieza) {
		
		this.pieza=pieza;
	}
	
	/**
	 * Devuelve true si la celda está vacia.
	 * @return True si la celda esta vacía
	 */
	public boolean estaVacia() {
		
		return pieza == null;
	}
	
	/**
	 * Devuelve la fila en la que esta la celda.
	 * @return Fila donde esta la celda
	 */
	public int obtenerFila() {
		
		return this.fila;
	}
	
	/**
	 * Obtenemos el color de la pieza de la celda, si es que hay pieza.
	 * @return Color de la pieza
	 */
	public Color obtenerColorDePieza() {
		if (estaVacia()==false) {
		return this.pieza.obtenerColor();
		}
		else return null;
	}
	
	/**
	 * Devuelve la columna en la que esta la celda.
	 * @return Columna donde esta la celda
	 */
	public int obtenerColumna() {
		
		return this.columna;
	}
	
	/**
	 * Devuelve la pieza que esta colocada en la celda.
	 * @return Pieza que esta en la celda.
	 */
	public Pieza obtenerPieza() {
		
		return this.pieza;
	}
	
	/**
	 * Compara dos celdas y nos dice si tienen coordenadas iguales.
	 * @param celda celda a comparar con la actual
	 * @return true si tienen coordenadas iguales o false si no
	 */
	public boolean tieneCoordenadasIguales(Celda celda) {
		
		if(this.fila==celda.obtenerFila() && this.columna==celda.obtenerColumna()) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	/**
	 * Devuelve la celda en el formato (fila/columna).
	 * @return (fila/columna)
	 */
	public String toString() {
		
		return "(" + this.fila + "/" + this.columna + ")";
	}
}
