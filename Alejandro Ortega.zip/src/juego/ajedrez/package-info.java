/**
 * Interfaz en modo texto.
 *
 * @author <a href="rmartico@ubu.es">Raúl Marticorena</a>
 * @since 1.0
 * @version 1.0
 */
package juego.ajedrez;