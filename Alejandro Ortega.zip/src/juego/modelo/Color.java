package juego.modelo;
/**
 * Enumeracion de los posibles colores de las piezas.
 * @author Alejandro Ortega Martínez
 * @version 1.0
 * @see Pieza
 *
 */
public enum Color {
	
	/**
	 * Color Blanco ('B').
	 */
	BLANCO('B'),
	/**
	 * Color Negro ('N').
	 */
	NEGRO('N');
	
	/**
	 * Letra que identifica al color.
	 */
	private char letra;
	
	/**
	 * Constructor de la enumeración.
	 * @param car caracter (B/N) que identifica al color.
	 */
	private Color (char car) {
		this.letra = car;
	}
	
	/**
	 * Devuelve el caracter que identifica al color en cuestión.
	 * @return caracter identificativo del color.
	 */
	public char toChar() {
		return letra;
	}
}
