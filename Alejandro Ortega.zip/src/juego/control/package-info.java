/**
 * Clase de control de las reglas de juego y desarrollo del mismo.
 *
 * @author Alejandro Ortega Martínez.
 * @since 1.0
 * @version 1.0
 */
package juego.control;