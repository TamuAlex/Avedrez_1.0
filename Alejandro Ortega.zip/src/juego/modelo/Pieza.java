package juego.modelo;
/**
 * Piezas del tablero de ajedrez.
 * @author Alejandro Ortega Martinez
 * @version 1.0
 * @see Color
 * @see Celda
 * @see Tipo
 *
 */
public class Pieza {
	/**
	 * Tipo de la pieza.
	 * @see TIpo
	 */
	private Tipo tipo;
	
	/**
	 * Color de la pieza.
	 * @see Color
	 */
	private Color color;
	
	/**
	 * Celda en la que se ubica la pieza.
	 * @see Celda
	 */
	private Celda celda;
	
	/**
	 * Variable que indica si la pieza ya ha realizado algún movimiento.
	 */
	private boolean primerMov=true;
	
	/**
	 * Constructor de la Pieza.
	 * @param tipo Tipo de la pieza que queremos crear.
	 * @see Tipo
	 * @param color Color de la pieza que queremos crear.
	 * @see Color
	 */
	public Pieza(Tipo tipo, Color color) {
		
		this.tipo=tipo;
		this.color=color;
		
	}
	
	/**
	 * Comprueba si la pieza ha realizado algún movimiento.
	 * @return True si es su primer movimiento y false si no.
	 */
	public boolean esPrimerMovimiento() {
		
		return primerMov;
		
	}
	
	/**
	 * Establece la celda en la que va a estar la pieza.
	 * @param celda celda en la que queremos colocar la pieza.
	 * @see celda
	 */
	public void establecerCelda(Celda celda) {
		
		this.celda=celda;
		
	}
	
	/**
	 * Marca que la pieza ya ha realizado su primer movimiento.
	 * @see primerMov
	 */
	public void marcarPrimerMovimiento() {
		
		this.primerMov=false;
		
	}
	
	/**
	 * Nos dice en que celda esta colocada la pieza.
	 * @return Celda en la que está la pieza.
	 * @see celda
	 */
	public Celda obtenerCelda() {
		
		return this.celda;
		
	}
	
	/**
	 * Nos dice el color de la pieza.
	 * @return Color de la pieza
	 * @see color
	 */
	public Color obtenerColor() {
		
		return this.color;
		
	}
	
	/**
	 * Nos dice el tipo de la pieza.
	 * @return Tipo de la pieza.
	 * @see tipo
	 */
	public Tipo obtenerTipo() {
		
		return this.tipo;
		
	}
	
	/**
	 * Metodo toString que devuelve los datos de la pieza.
	 * @return datos de la pieza en el formato PIEZA-COLOR-PrimerMovimiento
	 */
	public String toString() {
		
		return "" + this.tipo.toString() + "-" +this.obtenerColor().toString() + "-" + this.primerMov;
		
	}
}
